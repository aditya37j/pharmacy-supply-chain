CREATE OR REPLACE PROCEDURE Order_id (
  
    o_cust_id IN VARCHAR2,
   -- o_order_date IN DATE,
    o_totalamount IN NUMBER,
    p_new_id OUT VARCHAR2
) IS
    last_id NUMBER;
BEGIN
    -- Get the last inserted ID
    SELECT COUNT(*) INTO last_id FROM orders;

    -- Calculate the new ID
    p_new_id := 'O' || LPAD(last_id + 1, 3, '0');

    -- Insert the new customer record
    INSERT INTO orders (order_id,cus_id,order_date,totat_amount)
    VALUES (p_new_id,o_cust_id,SYSDATE,o_totalamount);
    

    delete from cart where cus_id = o_cust_id;
    -- Commit the transaction
    COMMIT;
    
    -- Display success message or perform any additional tasks if needed
    DBMS_OUTPUT.PUT_LINE('Customer inserted successfully with ID: ' || p_new_id);
END;
/
