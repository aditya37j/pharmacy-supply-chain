CREATE OR REPLACE PROCEDURE CreateOrderAndInsertItems (
    o_cust_id IN VARCHAR2,
    o_totalamount IN NUMBER,
    p_new_id OUT VARCHAR2
) IS
    last_id NUMBER;
BEGIN
    -- Get the last inserted ID
    SELECT COUNT(*) INTO last_id FROM orders;

    -- Calculate the new ID
    p_new_id := 'O' || LPAD(last_id + 1, 3, '0');

    -- Insert the new order record
    INSERT INTO orders (order_id, cus_id, order_date, totat_amount)
    VALUES (p_new_id, o_cust_id, SYSDATE, o_totalamount);

    -- Debug message
    DBMS_OUTPUT.PUT_LINE('Inserted order with ID: ' || p_new_id);

    -- Retrieve values from cart and insert into order_items
    FOR cart_row IN (SELECT product_name, pharmacy_name, price
                     FROM cart
                     WHERE cus_id = o_cust_id)
    LOOP
        DECLARE
            v_product_id VARCHAR2(5);
            v_pharmacy_id VARCHAR2(5);
        BEGIN
            -- Get product_id
            BEGIN
                SELECT product_id INTO v_product_id
                FROM product
                WHERE name = cart_row.product_name;
                DBMS_OUTPUT.PUT_LINE('Retrieved product_id: ' || v_product_id || ' for product_name: ' || cart_row.product_name);
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    DBMS_OUTPUT.PUT_LINE('Product with name ' || cart_row.product_name || ' not found.');
                    RAISE;
            END;

            -- Get pharmacy_id
            BEGIN
                SELECT pharmacy_id INTO v_pharmacy_id
                FROM pharmacy
                WHERE name = cart_row.pharmacy_name;
                DBMS_OUTPUT.PUT_LINE('Retrieved pharmacy_id: ' || v_pharmacy_id || ' for pharmacy_name: ' || cart_row.pharmacy_name);
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    DBMS_OUTPUT.PUT_LINE('Pharmacy with name ' || cart_row.pharmacy_name || ' not found.');
                    RAISE;
            END;

            -- Insert into order_items
            BEGIN
                INSERT INTO order_items (order_id, product_id, pharmacy_id, quantity, unit_price)
                VALUES (p_new_id, v_product_id, v_pharmacy_id, 1, cart_row.price);
                DBMS_OUTPUT.PUT_LINE('Inserted order item: ' || v_product_id || ', ' || v_pharmacy_id);
            EXCEPTION
                WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Error inserting order item: ' || SQLERRM);
                    RAISE;
            END;
        END;
    END LOOP;

    -- Commit the transaction
    COMMIT;

    -- Display success message
    DBMS_OUTPUT.PUT_LINE('Order inserted successfully with ID: ' || p_new_id);
EXCEPTION
    WHEN OTHERS THEN
        -- Rollback the transaction in case of error
        ROLLBACK;
        -- Display error message
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/






CREATE OR REPLACE PROCEDURE DeleteItemsFromCart (
    o_cust_id IN VARCHAR2
) IS
BEGIN
    -- Delete values from cart
    DELETE FROM cart WHERE cus_id = o_cust_id;
    
    -- Commit the transaction
    COMMIT;

    -- Display success message
    DBMS_OUTPUT.PUT_LINE('Deleted items from cart for customer: ' || o_cust_id);
EXCEPTION
    WHEN OTHERS THEN
        -- Rollback the transaction in case of error
        ROLLBACK;
        -- Display error message
        DBMS_OUTPUT.PUT_LINE('Error deleting from cart: ' || SQLERRM);
END;
/
