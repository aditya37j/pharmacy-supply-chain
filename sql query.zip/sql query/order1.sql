CREATE OR REPLACE PROCEDURE Order_id (
    o_cust_id IN VARCHAR2,
    o_totalamount IN NUMBER,
    p_new_id OUT VARCHAR2
) IS
     last_id NUMBER;
BEGIN
    -- Get the last inserted ID
    -- Get the last inserted ID
    SELECT COUNT(*) INTO last_id FROM orders;

    -- Calculate the new ID
    p_new_id := 'O' || LPAD(last_id + 1, 3, '0');

    -- Insert the new order record
    INSERT INTO orders (order_id, cus_id, order_date, totat_amount)
    VALUES (p_new_id, o_cust_id, SYSDATE, o_totalamount);

    -- Retrieve values from cart
    FOR cart_row IN (SELECT product_name, pharmacy_name,price
                     FROM cart
                     WHERE cus_id = o_cust_id)
    LOOP
        -- Get product_id based on product_name
        DECLARE
            v_product_id VARCHAR2(5);
            v_pharmacy_id VARCHAR2(5);
        BEGIN
            


            -- Insert into order_items
            INSERT INTO order_list (order_id, product_name, pharmacy_name, quantity, unit_price)
            VALUES (p_new_id, cart_row.product_name,cart_row.pharmacy_name, 1, cart_row.price);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                -- Handle case where product name does not exist
                DBMS_OUTPUT.PUT_LINE('Product with name ' || cart_row.product_name || ' not found.');
        END;
    END LOOP;

    -- Delete values from cart
    DELETE FROM cart WHERE cus_id = o_cust_id;

    -- Commit the transaction
    COMMIT;

    -- Display success message
    DBMS_OUTPUT.PUT_LINE('Order inserted successfully with ID: ' || p_new_id);
EXCEPTION
    WHEN OTHERS THEN
        -- Display error message
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/
