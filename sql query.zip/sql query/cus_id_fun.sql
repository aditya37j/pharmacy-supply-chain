CREATE OR REPLACE PROCEDURE InsertCustomer (
    p_name IN VARCHAR2,
    p_phone IN VARCHAR2,
    p_email IN VARCHAR2,
    p_dob IN DATE,
    p_new_id OUT VARCHAR2
) IS
    last_id NUMBER;
BEGIN
    -- Get the last inserted ID
    SELECT COUNT(*) INTO last_id FROM customer;

    -- Calculate the new ID
    p_new_id := 'C' || LPAD(last_id + 1, 3, '0');

    -- Insert the new customer record
    INSERT INTO customer (cus_id, name, email, phone, dob)
    VALUES (p_new_id, p_name, p_email, p_phone, p_dob);

    -- Commit the transaction
    COMMIT;
    
    -- Display success message or perform any additional tasks if needed
    DBMS_OUTPUT.PUT_LINE('Customer inserted successfully with ID: ' || p_new_id);
END;
/
