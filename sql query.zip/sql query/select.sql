CREATE VIEW MedicineInventoryView AS
SELECT ph.pharmacy_id, ph.name AS pharmacy_name, p.product_id, p.name AS product_name, i.quantity,p.description as description,p.price as price
FROM product p
JOIN inventory i ON p.product_id = i.product_id
JOIN pharmacy ph ON i.pharmacy_id = ph.pharmacy_id;


CREATE VIEW supplier_distribution_summary AS
SELECT supplier_id,pharmacy_id,product_id,dist_date
 FROM distribution
GROUP BY supplier_id,pharmacy_id,product_id,dist_date;



CREATE VIEW newupdate_summary AS
SELECT supplier_id,pharmacy_id,
       product_id,
       qty
FROM newupdate
GROUP BY pharmacy_id, supplier_id, product_id,qty;




CREATE VIEW pharmacy_inventory_summary AS
SELECT i.pharmacy_id, i.product_id, p.name, SUM(i.quantity) AS total_quantity, i.supplier_id
FROM inventory i
JOIN product p ON p.product_id = i.product_id
GROUP BY i.pharmacy_id, i.product_id, p.name, i.supplier_id;