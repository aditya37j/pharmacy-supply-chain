drop table order_list;
drop table order_items;
drop table inventory;
drop table orders;
drop table distribution;
drop table address;
drop table customer;
drop table pharmacy;
drop table product;
drop table supplier;
drop table payemnt;
drop table shipment;

create table customer(
    cus_id varchar(5) constraint cus_pk primary key,
    name varchar(15),
    email varchar(25),
    phone number(10),
    dob date
);

insert into customer values ('C001','hari','hari@2004',9012345432,'12-MAR-2004');

create table pharmacy(
    pharmacy_id varchar(5) constraint pharm_pk primary key,
    name varchar(10),
    phone number(10),
    email varchar(25)
);
INSERT INTO pharmacy VALUES ('ph01', 'Pharmacy1', '1234567890', 'pharmacy1@ex.com');
INSERT INTO pharmacy VALUES ('ph02', 'Pharmacy2', '2345678901', 'pharmacy2@ex.com');
INSERT INTO pharmacy VALUES ('ph03', 'Pharmacy3', '3456789012', 'pharmacy3@ex.com');
INSERT INTO pharmacy VALUES ('ph04', 'Pharmacy4', '4567890123', 'pharmacy4@ex.com');


create table product(
    product_id varchar(5) constraint prod_pk primary key,
    name varchar(20),
    description varchar(20),
    price number
);


INSERT INTO product values ('p001', 'Paracetamol', 'fever', 15);
INSERT INTO product values  ('p002', 'Ibuprofen', 'fever', 18);
INSERT INTO product values  ('p003', 'Aspirin', 'fever', 14);
INSERT INTO product values ('p004', 'Cough_Syrup', 'cough', 35);
INSERT INTO product values ('p005', 'Throat_Lozenges', 'cough', 20);
INSERT INTO product values ('p006', 'Antihistamine', 'cold', 30);
INSERT INTO product values ('p007', 'Decongestant', 'cold', 28);
INSERT INTO product values ('p008', 'Antacid', 'indigestion', 45);
INSERT INTO product values ('p009', 'Antidiarrheal', 'diarrhea', 40);

create table supplier(
    supplier_id varchar(5) constraint sup_pk primary key,
    name varchar(30),
    phone number(10),
    email varchar(30)
);

insert into supplier values ('S001', 'ABC Pharmaceuticals', '1234567890', 'abcpharma@example.com');
insert into supplier values ('S002', 'XYZ Medical Supplies', '2345678901', 'xyzmed@example.com');
insert into supplier values ('S003', 'MediCorp', '3456789012', 'medicorp@example.com');
insert into supplier values ('S004', 'HealthCare Distributors', '4567890123', 'healthcare@example.com');
 


CREATE TABLE inventory (
    pharmacy_id varchar(5),
    product_id varchar(5),
    supplier_id varchar(5),
    quantity int,
    PRIMARY KEY (pharmacy_id, product_id),
    FOREIGN KEY (pharmacy_id) REFERENCES pharmacy(pharmacy_id),
    FOREIGN KEY (product_id) REFERENCES product(product_id),
    FOREIGN KEY (supplier_id) REFERENCES supplier(supplier_id)
);

-- Pharmacy 1
INSERT INTO inventory VALUES ('ph01', 'p001', 'S001', 100);
INSERT INTO inventory VALUES ('ph01', 'p002', 'S002', 18);
INSERT INTO inventory VALUES ('ph01', 'p003', 'S003', 5);
INSERT INTO inventory VALUES ('ph01', 'p004', 'S004', 100);
INSERT INTO inventory VALUES ('ph01', 'p005', 'S001', 7);
INSERT INTO inventory VALUES ('ph01', 'p006', 'S002', 100);
INSERT INTO inventory VALUES ('ph01', 'p007', 'S003', 3);
INSERT INTO inventory VALUES ('ph01', 'p008', 'S004', 100);
INSERT INTO inventory VALUES ('ph01', 'p009', 'S001', 100);

-- Pharmacy 2
INSERT INTO inventory VALUES ('ph02', 'p001', 'S002', 4);
INSERT INTO inventory VALUES ('ph02', 'p002', 'S003', 100);
INSERT INTO inventory VALUES ('ph02', 'p003', 'S004', 100);
INSERT INTO inventory VALUES ('ph02', 'p004', 'S001', 100);
INSERT INTO inventory VALUES ('ph02', 'p005', 'S002', 100);
INSERT INTO inventory VALUES ('ph02', 'p006', 'S003', 3);
INSERT INTO inventory VALUES ('ph02', 'p007', 'S004', 8);
INSERT INTO inventory VALUES ('ph02', 'p008', 'S001', 5);
INSERT INTO inventory VALUES ('ph02', 'p009', 'S002', 100);

-- Pharmacy 3
INSERT INTO inventory VALUES ('ph03', 'p001', 'S003', 6);
INSERT INTO inventory VALUES ('ph03', 'p002', 'S004', 100);
INSERT INTO inventory VALUES ('ph03', 'p003', 'S001', 100);
INSERT INTO inventory VALUES ('ph03', 'p004', 'S002', 1);
INSERT INTO inventory VALUES ('ph03', 'p005', 'S003', 100);
INSERT INTO inventory VALUES ('ph03', 'p006', 'S004', 8);
INSERT INTO inventory VALUES ('ph03', 'p007', 'S001', 100);
INSERT INTO inventory VALUES ('ph03', 'p008', 'S002',5)
INSERT INTO inventory VALUES ('ph03', 'p009', 'S003', 100);

-- Pharmacy 4
INSERT INTO inventory VALUES ('ph04', 'p001', 'S004', 100);
INSERT INTO inventory VALUES ('ph04', 'p002', 'S001', 100);
INSERT INTO inventory VALUES ('ph04', 'p003', 'S002', 100);
INSERT INTO inventory VALUES ('ph04', 'p004', 'S003', 100);
INSERT INTO inventory VALUES ('ph04', 'p005', 'S004', 100);
INSERT INTO inventory VALUES ('ph04', 'p006', 'S001', 100);
INSERT INTO inventory VALUES ('ph04', 'p007', 'S002', 100);
INSERT INTO inventory VALUES ('ph04', 'p008', 'S003', 100);
INSERT INTO inventory VALUES ('ph04', 'p009', 'S004', 100);


 create table cart(
cus_id varchar(5),
 pharmacy_name varchar(20),
 product_name varchar(20),
 description varchar(20),
 price number);



create table orders(
    order_id varchar(5) constraint ord_pk primary key,
    cus_id varchar(5) references customer(cus_id),
    order_date date,
    totat_amount number
);
insert into orders values('0001','C001','06-JUN-2004','55');



create table order_items(
    order_id varchar(5) references orders(order_id),
    product_id varchar(5) references product(product_id),
    pharmacy_id varchar(5) references pharmacy(pharmacy_id),
    quantity int,
    unit_price int,
    PRIMARY KEY(order_id,product_id)
);


create table order_list(
    order_id varchar(5) references orders(order_id),
    product_name varchar(5) ,
    pharmacy_name varchar(5) ,
    quantity int,
    unit_price int,
    PRIMARY KEY(order_id,product_name)
);


SQL> desc order_list;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 ORDER_ID                                  NOT NULL VARCHAR2(5)
 PRODUCT_NAME                              NOT NULL VARCHAR2(20)
 PHARMACY_NAME                                      VARCHAR2(20)
 QUANTITY                                           NUMBER(38)
 UNIT_PRICE                                         NUMBER(38)
